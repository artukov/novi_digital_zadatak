import { LockOutlined } from "@mui/icons-material";
import {
  Container,
  CssBaseline,
  Box,
  Avatar,
  Typography,
  TextField,
  Button,
  Grid,
} from "@mui/material";
import { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { login } from "../api";
import { toast } from "react-toastify";

const Login = () => {
    const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);

  const handleLogin = async () => {
        try {
        // Validate fields
        if (!email || !password) {
            toast.error("Please enter all fields");
            return;
        }

        const response = await login({ email, password });

        if (response.status === 200) {
            const token = response.data?.token;
            localStorage.setItem("token", token);
            setUser(response.data.user); // Update user state with user data
        } else {
            toast.error("Login failed. Please try again.");
        }
        } catch (error) {
        console.error("Login error:", error);
        toast.error("Login failed. Please try again.");
        }
    };

    // If user is logged in (based on user state), redirect immediately
    if (user) {
        return <Navigate to="/" replace />;
    }
  
    return (
      <>
        <Container maxWidth="xs">
          <CssBaseline />
          <Box
            sx={{
              mt: 20,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <Avatar sx={{ m: 1, bgcolor: "primary.light" }}>
              <LockOutlined />
            </Avatar>
            <Typography variant="h5">Login</Typography>
            <Box sx={{ mt: 1 }}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
  
              <TextField
                margin="normal"
                required
                fullWidth
                id="password"
                name="password"
                label="Password"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
  
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
                onClick={handleLogin}
              >
                Login
              </Button>
              <Grid container justifyContent={"flex-end"}>
                <Grid item>
                  <Link to="/register">Don't have an account? Register</Link>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Container>
      </>
    );
}

export default Login