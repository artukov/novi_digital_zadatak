export interface Errors {
    firstName?: string;
    lastName?: string;
    email?: string;
    password?: string;
    api?: string;
  }